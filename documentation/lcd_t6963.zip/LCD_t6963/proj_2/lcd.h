
////////////////////////////////////////////

//  Jan Kedzierski
  
//       2006


////////////////////////////////////////////


#define LCD_DR 0xeff800             /* adres rejestru danych LCD */
#define LCD_IR LCD_DR+1             /* adres rejestru sterujacego LCD */


volatile char LcdIr @LCD_IR;
volatile char LcdDr @LCD_DR; 


void lcd_data(char, unsigned char);  
void lcd_cmd_2(char, unsigned int);
void lcd_cmd(char);
void Lcd_Init(); 
void Lcd_Put_Text(int,int,char *) ;
void Lcd_Put_Graphic(unsigned int,unsigned int,unsigned int,char *);
void Lcd_clear_graph();
void Lcd_clear_text();
void Lcd_pixel(int, int ,char );
void Lcd_line(int,int,int,int,unsigned char);
void Lcd_circle(int,int, int, unsigned char);
void Lcd_box(int,int,int,int,unsigned char);
void Lcd_circle_segment(int,int,int,int,int,unsigned char); 
void Lcd_box_filled (int,int,int,int,unsigned char );
void Lcd_V_line (int,int,int, unsigned char);
void Lcd_H_line (int,int,int, unsigned char);
void Lcd_window (int,int,int,int,char *, unsigned char);
	   

