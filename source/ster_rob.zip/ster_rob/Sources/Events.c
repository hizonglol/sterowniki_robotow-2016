/* ###################################################################
**     Filename    : Events.c
**     Project     : ster_rob
**     Processor   : MK60FX512VLQ15
**     Component   : Events
**     Version     : Driver 01.00
**     Compiler    : GNU C Compiler
**     Date/Time   : 2016-03-27, 21:36, # CodeGen: 0
**     Abstract    :
**         This is user's event module.
**         Put your event handler code here.
**     Settings    :
**     Contents    :
**         Cpu_OnNMIINT - void Cpu_OnNMIINT(void);
**
** ###################################################################*/
/*!
** @file Events.c
** @version 01.00
** @brief
**         This is user's event module.
**         Put your event handler code here.
*/         
/*!
**  @addtogroup Events_module Events module documentation
**  @{
*/         
/* MODULE Events */

#include "Cpu.h"
#include "Events.h"

#ifdef __cplusplus
extern "C" {
#endif 


/* User includes (#include below this line is not maintained by Processor Expert) */

/*
** ===================================================================
**     Event       :  Cpu_OnNMIINT (module Events)
**
**     Component   :  Cpu [MK60FN1M0LQ15]
*/
/*!
**     @brief
**         This event is called when the Non maskable interrupt had
**         occurred. This event is automatically enabled when the [NMI
**         interrupt] property is set to 'Enabled'.
*/
/* ===================================================================*/
void Cpu_OnNMIINT(void)
{
  /* Write your code here ... */
}

/*
** ===================================================================
**     Event       :  periodyczne_OnInterrupt (module Events)
**
**     Component   :  periodyczne [TimerInt_LDD]
*/
/*!
**     @brief
**         Called if periodic event occur. Component and OnInterrupt
**         event must be enabled. See [SetEventMask] and [GetEventMask]
**         methods. This event is available only if a [Interrupt
**         service/event] is enabled.
**     @param
**         UserDataPtr     - Pointer to the user or
**                           RTOS specific data. The pointer passed as
**                           the parameter of Init method.
*/
/* ===================================================================*/
void periodyczne_OnInterrupt(LDD_TUserData *UserDataPtr)
{
	/*
	extern char str_pomiar[];
	extern char greeting[];
	extern char clearscr[];
	extern char setpointer[];
	uint16 i;
	
	for(i=0; i<7; ++i){
		UART_SendChar(clearscr[i]);
	}
	for(i=0; i<8; ++i){
		UART_SendChar(setpointer[i]);
	}
	*/
	
	/*
	for(i=0; i<11; ++i){
		UART_SendChar(greeting[i]);
	}
	*/
	
	/*
	for(i=0; i<30; ++i){
		UART_SendChar(str_pomiar[i]);
	}
	dioda3_NegVal(NULL);
	*/
}

/*
** ===================================================================
**     Event       :  extINT_OnInterrupt (module Events)
**
**     Component   :  extINT [ExtInt_LDD]
*/
/*!
**     @brief
**         This event is called when an active signal edge/level has
**         occurred.
**     @param
**         UserDataPtr     - Pointer to RTOS device
**                           data structure pointer.
*/
/* ===================================================================*/
void extINT_OnInterrupt(LDD_TUserData *UserDataPtr)
{
	//
	//dioda1_NegVal(NULL);
	//serwo_SetDutyMS(1);
	//delay(1000);
}

/* END Events */

#ifdef __cplusplus
}  /* extern "C" */
#endif 

/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.3 [05.09]
**     for the Freescale Kinetis series of microcontrollers.
**
** ###################################################################
*/
