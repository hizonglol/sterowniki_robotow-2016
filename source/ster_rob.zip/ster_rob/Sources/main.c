/* ###################################################################
**     Filename    : main.c
**     Project     : ster_rob
**     Processor   : MK60FX512VLQ15
**     Version     : Driver 01.01
**     Compiler    : GNU C Compiler
**     Date/Time   : 2016-03-27, 21:36, # CodeGen: 0
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file main.c
** @version 01.01
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */


/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "GR.h"
#include "IntI2cLdd1.h"
/* Including shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"

/* User includes (#include below this line is not maintained by Processor Expert) */
//char greeting[] = "Hello world";
//char clearscr[] = "\033[2J";
//char setpointer[] = "\033[0;0H";
byte recive[15];
byte send[5];
int16 x,y,z;
byte ret=0;
byte tmp=0;
word err1;
word GR_SndRcvTemp;   /* Temporary variable for SendChar (RecvChar) when they call SendBlock (RecvBlock) */
int i;
//Adres tego zyroskopu to jest chyba na stronie 33 dokumentacji
//1101010

/*lint -save  -e970 Disable MISRA rule (6.3) checking. */
int main(void)
/*lint -restore Enable MISRA rule (6.3) checking. */
{
  /* Write your local variable definition here */

  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  PE_low_level_init();
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
  (void)memset(recive,0,sizeof(recive)); 
  (void)memset(send,0,sizeof(send)); 
  
  err1=GR_SelectSlave(0x0F);
  send[0]=0x20;	// CTRL_REG1
  send[1]=0x0F;
  ret=GR_SendBlock(send,2U,&GR_SndRcvTemp);
  GR_SendStop();
  
  send[0]=0x22;
  send[1]=0x88;
  ret=GR_SendBlock(send,2U,&GR_SndRcvTemp);
  GR_SendStop();
  

/*
  byte c = gReadByte(CTRL_REG5_G);
  gWriteByte(CTRL_REG5_G, c | 0x40);         // Enable gyro FIFO  
  delay(20);                                 // Wait for change to take effect
  gWriteByte(FIFO_CTRL_REG_G, 0x20 | 0x1F);  // Enable gyro FIFO stream mode and set watermark at 32 samples
  delay(1000);  // delay 1000 milliseconds to collect FIFO samples
  */
  
  // Wait for GR ready
  for(i=0;i<=100000;i++) {}
  
  for(;;) {
	  err1=GR_SelectSlave(0x0F);
	  /*
	  ret=GR_RecvBlock(recive,8,&GR_SndRcvTemp);
	  GR_SendStop();
	  
	  x=((int16)recive[1]<<8)+(int16)recive[0];
	  y=((int16)recive[3]<<8)+(int16)recive[2];
	  z=((int16)recive[5]<<8)+(int16)recive[4]; 
	  */

	  for(i=0;i<=10000;i++) {}
	  
  }

  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.3 [05.09]
**     for the Freescale Kinetis series of microcontrollers.
**
** ###################################################################
*/
